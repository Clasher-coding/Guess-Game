const categories = {
    animals: {
        title: "Guess the Animal",
        images: [
            "https://cdn.pixabay.com/photo/2017/11/09/21/41/cat-2934720_640.jpg", 
            "https://cdn.pixabay.com/photo/2020/10/06/04/11/rough-collie-5631188_640.jpg",
            "https://cdn.pixabay.com/photo/2023/02/26/02/55/elephant-7814673_640.jpg",
            "https://cdn.pixabay.com/photo/2017/10/05/18/35/lion-2820443_640.jpg",
            "https://cdn.pixabay.com/photo/2022/07/10/14/11/masai-giraffe-7312959_640.jpg"
        ],
        answers: ["Cat", "Dog", "Elephant", "Lion", "Giraffe"]
    },
    vegetables: {
        title: "Guess the Vegetable",
        images: [
            "https://upload.wikimedia.org/wikipedia/commons/7/70/Carrot.jpg",
            "https://upload.wikimedia.org/wikipedia/commons/3/32/Broccoli_and_cross_section_edit.jpg",
            "https://upload.wikimedia.org/wikipedia/commons/4/47/Potato_and_cross_section.jpg",
            "https://upload.wikimedia.org/wikipedia/commons/8/89/Tomato_je.jpg",
            "https://upload.wikimedia.org/wikipedia/commons/6/6f/Cabbage_and_cross_section_on_white.jpg"
        ],
        answers: ["Carrot", "Broccoli", "Potato", "Tomato", "Cabbage"]
    },
    fruits: {
        title: "Guess the Fruit",
        images: [
            "https://upload.wikimedia.org/wikipedia/commons/1/15/Red_Apple.jpg",
            "https://upload.wikimedia.org/wikipedia/commons/8/8a/Banana-Single.jpg",
            "https://upload.wikimedia.org/wikipedia/commons/b/bb/Cherry_Stella444.jpg",
            "https://upload.wikimedia.org/wikipedia/commons/c/c4/Orange-Fruit-Pieces.jpg",
            "https://upload.wikimedia.org/wikipedia/commons/3/32/Blue_Grapes.jpg"
        ],
        answers: ["Apple", "Banana", "Cherry", "Orange", "Grapes"]
    }
};


let categorySelector = document.getElementById("category-selector");
let title = document.getElementById("game-title");
let image = document.getElementById("game-image");
let dropZone = document.getElementById("drop-zone");
let optionsContainer = document.getElementById("options");
let nextBtn = document.getElementById("next-btn");

let currentIndex = 0;
let blurInterval;
let gameData;


function loadGame(category) {
    gameData = categories[category];
    title.textContent = gameData.title;
    currentIndex = Math.floor(Math.random() * gameData.images.length); 
    loadNext();
}


function startBlurReduction() {
    let blurValue = 15;
    blurInterval = setInterval(() => {
        if (blurValue > 0) {
            blurValue -= 1;
            image.style.filter = `blur(${blurValue}px)`;
        } else {
            clearInterval(blurInterval);
        }
    }, 1000);
}


function loadNext() {
    if (currentIndex < gameData.images.length) {
        image.src = gameData.images[currentIndex];
        image.style.filter = "blur(15px)";
        dropZone.textContent = "Drop Here";
        dropZone.style.backgroundColor = "white";
        nextBtn.disabled = true;
        updateOptions();
        clearInterval(blurInterval);
        startBlurReduction();
    } else {
        alert("Congratulations! You've completed the game!");
    }
}


function updateOptions() {
    optionsContainer.innerHTML = "";
    let options = [...gameData.answers].sort(() => Math.random() - 0.5);

    options.forEach(optionText => {
        let option = document.createElement("div");
        option.classList.add("option");
        option.draggable = true;
        option.textContent = optionText;
        option.addEventListener("dragstart", function(event) {
            event.dataTransfer.setData("text", event.target.textContent);
        });
        optionsContainer.appendChild(option);
    });
}


dropZone.addEventListener("dragover", function(event) {
    event.preventDefault();
});
dropZone.addEventListener("drop", function(event) {
    event.preventDefault();
    let droppedText = event.dataTransfer.getData("text");

    if (droppedText === gameData.answers[currentIndex]) {
        clearInterval(blurInterval);
        image.style.filter = "blur(0px)";
        dropZone.textContent = `Correct! It's a ${droppedText}!`;
        dropZone.style.backgroundColor = "#2ecc71";
        nextBtn.disabled = false;
    } else {
        dropZone.textContent = `Incorrect! Try Again!`;
        dropZone.style.backgroundColor = "#e74c3c";
    }
});


categorySelector.addEventListener("change", function() {
    loadGame(this.value);
});


nextBtn.addEventListener("click", function() {
    currentIndex++;
    loadNext();
});

loadGame("animals");
